# -*- coding: utf-8 -*-
"""
Created on Fri Apr 29 19:57:09 2022

@author: sravula
"""
import os

class config():
 INPUT_DATA_DIR = os.path.join('data')
 OUTPUT_DATA_DIR = os.path.join('data')
 